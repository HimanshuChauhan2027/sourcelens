# Sarvottam Cables Ltd (SRVCABLE)

As of: 2026-09-23

## Snapshot

Sarvottam Cables Ltd manufactures power cables, wires and conductors. [S03]
Q1 FY27 revenue and profit rose, though sources differ on the exact revenue figure. [S01] [S03]
Operating margins contracted by 170 basis points to 11.2% as copper costs rose. [S01] [S03]

## Bull case

- Management maintains FY27 revenue growth guidance of 15‑17% and expects the new Bharuch plant to contribute from the second half. [S02] [S03]
- Data‑centre cables are about 9% of domestic revenue and management sees potential to double that share in two years. [S02]
- Leverage is low (net debt to equity 0.35), promoter pledging is minimal (4.1%), and the GST demand is expected to have no material impact. [S02] [S07] [S08]

## Bear case

- Copper cost pressures may persist if the company cannot pass on higher raw material prices due to lagged price‑variation clauses in contracts. [S01] [S02]
- Receivable days rose from 78 to 96, indicating slower payments from state utilities and potential working‑capital strain. [S02]
- The GST demand of ₹46.3 crore could affect finances if the intended appeal fails, despite management’s expectation of no material impact. [S07]

## Open questions

- Can the company pass on copper cost increases to customers given the one‑ to two‑quarter lag in price‑variation clauses? [S01] [S02]
- What is the expected timeline and possible financial impact of the GST demand appeal? [S07]

## Sources

- [S01] businessdaily_2026-08-09.md | Business Daily Online (news website) | 2026-08-09 | https://businessdaily.example/markets/sarvottam-cables-q1-results
- [S02] ir_concall_2026-08-11.md | Q1 FY27 earnings call transcript (excerpt), hosted on company IR site | 2026-08-11 | https://ir.sarvottamcables.example/transcripts/q1fy27.pdf
- [S03] ir_press_release_2026-08-08.md | Sarvottam Cables Ltd, investor relations (company press release) | 2026-08-08 | https://ir.sarvottamcables.example/press/q1fy27
- [S07] nse_announcement_2026-09-02.md | NSE corporate announcement (company disclosure) | 2026-09-02 | https://nse.example/announcements/SRVCABLE/2026-09-02
- [S08] nse_shareholding_2026-07-15.md | NSE shareholding pattern filing (summary) | 2026-07-15 | https://nse.example/shareholding/SRVCABLE/2026-06
