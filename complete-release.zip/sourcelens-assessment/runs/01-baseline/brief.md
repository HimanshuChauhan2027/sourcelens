# Sarvottam Cables (SRVCABLE)
Research date: 23 September 2026

## Snapshot
Sarvottam Cables makes power cables, wires and conductors; its latest supplied results cover the quarter ended 30 June 2026. [S03]
The company reports revenue of ₹1,248 crore, up 18.0%; this primary disclosure takes precedence over the news article’s conflicting ₹1,428 crore and 35% growth. [S03][S01]
Profit rose 5.9% to ₹82 crore, while EBITDA margin fell from 12.9% to 11.2%: stronger sales have yet to produce comparable profit growth. [S03]

## Bull case
- The ₹3,900 crore order book, versus ₹3,150 crore a year earlier, supports demand visibility. Exports increased from 16% to 21% of revenue, widening the sales mix. [S03]
- Bharuch is expected to add about 30% to cable capacity and begin commercial production in Q3 FY27. Management maintains FY27 revenue-growth guidance of 15–17%; both timing and growth remain expectations. [S03][S02]
- Management says two-thirds of contracts allow price adjustments, offering a route to recover copper-cost increases, although resets take one to two quarters. [S02]
- Promoter pledging was 4.1% of promoter holdings on 30 June 2026, down from 11.5% a year earlier. This newer exchange filing supersedes the 35% figure in the March 2024 article for assessing recent exposure. [S08][S04]

## Bear case
- The 170-basis-point margin decline shows vulnerability to raw-material costs. Management attributes it mainly to copper, but recovery depends on delayed customer price adjustments. [S03][S02]
- Receivable days increased from 78 to 96, mainly because two state utilities are paying more slowly. Management reports no defaults, but delayed collections constrain cash while the ₹620 crore Bharuch project is being funded; about 70% is spent and net debt/equity is 0.35 times. [S02]
- The September GST demand totals ₹46.3 crore, including interest and penalty. The company intends to appeal and expects no material impact, but those are management’s assessments; the disclosure does not establish a favourable outcome. [S07]

## Open questions
- Will copper pass-through restore margins over the next two quarters, and will utility collections improve? These determine whether reported growth converts into stronger earnings and cash. [S03][S02]
- Will Bharuch meet its Q3 FY27 production schedule, and how quickly will its added capacity generate sales? [S03][S02]
Not supplied in the pack: A current share price and valuation, detailed cash-flow statements, and the GST appeal’s subsequent status and accounting treatment.

## Sources
- [S01] businessdaily_2026-08-09.md — Published 2026-08-09 — https://businessdaily.example/markets/sarvottam-cables-q1-results
- [S02] ir_concall_2026-08-11.md — Published 2026-08-11 — https://ir.sarvottamcables.example/transcripts/q1fy27.pdf
- [S03] ir_press_release_2026-08-08.md — Published 2026-08-08 — https://ir.sarvottamcables.example/press/q1fy27
- [S04] marketwatchindia_2024-03-18.md — Published 2024-03-18 — https://marketwatchindia.example/2024/03/sarvottam-promoter-pledge
- [S07] nse_announcement_2026-09-02.md — Published 2026-09-02 — https://nse.example/announcements/SRVCABLE/2026-09-02
- [S08] nse_shareholding_2026-07-15.md — Published 2026-07-15 — https://nse.example/shareholding/SRVCABLE/2026-06