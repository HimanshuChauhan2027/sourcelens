# Sarvottam Cables Ltd (SRVCABLE)

As of: 2026-09-23

## Snapshot

Sarvottam Cables manufactures power cables, wires, and conductors. [S03]
Q1 FY27 revenue rose 18.0% to ₹1,248 crore; profit after tax rose 5.9% to ₹82 crore. [S03]
EBITDA margin contracted 170 basis points to 11.2% due to higher copper costs. [S03]

## Bull case

- Q1 FY27 revenue from operations was ₹1,248 crore, up 18.0% year-on-year. [S03]
- Management thinks data-centre cables can double in two years. [S02]
- Order book reached ₹3,900 crore, up from ₹3,150 crore a year ago. [S03]

## Bear case

- EBITDA margin contracted 170 basis points to 11.2% in Q1 FY27. [S03]
- Receivable days increased from 78 to 96 over the last year. [S02]
- Company received a ₹46.3 crore GST demand order for FY2020-21 and FY2021-22. [S07]

## Open questions

- Management states price-variation clauses reset with a lag; can they offset copper costs? [S02]
- Management intends to appeal the GST demand and does not expect material impact. [S07]

## Sources

- [S02] ir_concall_2026-08-11.md | Q1 FY27 earnings call transcript (excerpt), hosted on company IR site | 2026-08-11 | https://ir.sarvottamcables.example/transcripts/q1fy27.pdf
- [S03] ir_press_release_2026-08-08.md | Sarvottam Cables Ltd, investor relations (company press release) | 2026-08-08 | https://ir.sarvottamcables.example/press/q1fy27
- [S07] nse_announcement_2026-09-02.md | NSE corporate announcement (company disclosure) | 2026-09-02 | https://nse.example/announcements/SRVCABLE/2026-09-02
