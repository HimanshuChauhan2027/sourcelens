# Sarvottam Cables Ltd (SRVCABLE)

As of: 2026-09-23

## Snapshot

Sarvottam Cables Ltd manufactures power cables, wires, and conductors for power transmission and data-centre projects. [S03]
Consolidated revenue grew 18.0% YoY to ₹1,248 crore, while net profit rose 5.9% to ₹82 crore in Q1 FY27. [S03]
EBITDA margin contracted by 170 basis points to 11.2% due to rising copper prices, though the order book grew to ₹3,900 crore. [S03]

## Bull case

- The new Bharuch plant will add 30% to cable capacity in Q3 FY27, and data-centre cables can double from their current 9% share of domestic revenue. [S02] [S03]
- Management maintains full-year FY27 revenue growth guidance of 15–17% and expects to pass on higher copper costs to customers over the next two quarters. [S02] [S03]
- Promoter pledging fell to 4.1%, institutional holdings increased, and net debt-to-equity remains low at 0.35 times with capex largely funded internally. [S02] [S03] [S08]

## Bear case

- Operating margins contracted by 170 basis points to 11.2% as copper prices rose nearly 14%, squeezing profitability despite 18% revenue growth. [S01] [S03]
- Management states that only two-thirds of contracts have price-variation clauses, which reset with a lag of one to two quarters, leaving the company exposed to copper cost volatility in the near term. [S02] [S03]
- Receivable days increased from 78 to 96 days due to slower payments from two large state utility customers, increasing working capital requirements. [S02]

## Open questions

- What is the financial impact of the ₹46.3 crore GST demand order for FY2020-21 and FY2021-22, and will the intended appeal succeed? [S07]
- How will the company manage further increases in receivable days if state utility payment delays persist? [S02]

## Sources

- [S01] businessdaily_2026-08-09.md | Business Daily Online (news website) | 2026-08-09 | https://businessdaily.example/markets/sarvottam-cables-q1-results
- [S02] ir_concall_2026-08-11.md | Q1 FY27 earnings call transcript (excerpt), hosted on company IR site | 2026-08-11 | https://ir.sarvottamcables.example/transcripts/q1fy27.pdf
- [S03] ir_press_release_2026-08-08.md | Sarvottam Cables Ltd, investor relations (company press release) | 2026-08-08 | https://ir.sarvottamcables.example/press/q1fy27
- [S07] nse_announcement_2026-09-02.md | NSE corporate announcement (company disclosure) | 2026-09-02 | https://nse.example/announcements/SRVCABLE/2026-09-02
- [S08] nse_shareholding_2026-07-15.md | NSE shareholding pattern filing (summary) | 2026-07-15 | https://nse.example/shareholding/SRVCABLE/2026-06
