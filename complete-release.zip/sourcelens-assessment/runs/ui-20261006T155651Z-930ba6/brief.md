# Sarvottam Cables Ltd (SRVCABLE)

As of: 2026-09-23

## Snapshot

Sarvottam Cables manufactures power cables, wires, and conductors. [S03]
Q1 FY27 revenue rose 18% to ₹1,248 crore; PAT rose 5.9% to ₹82 crore. [S03]
EBITDA margin contracted 170 bps to 11.2%, primarily due to copper costs. [S02] [S03]

## Bull case

- Order book reached ₹3,900 crore, up from ₹3,150 crore a year ago. [S03]
- Management thinks data-centre cables can double in two years. [S02]
- Bharuch plant adds 30% capacity; 70% of ₹620 crore capex spent. [S02] [S03]

## Bear case

- EBITDA margin fell 170 bps to 11.2% as copper costs rose, outpacing revenue growth. [S02] [S03]
- Receivable days increased from 78 to 96, driven by slower payments from two state utilities. [S02]
- Company received a ₹46.3 crore GST demand order for FY2020-21 and FY2021-22 input tax credits. [S07]

## Open questions

- Why does secondary reporting cite ₹1,428 crore revenue while the company filing reports ₹1,248 crore? [S01] [S03]
- Will the company's appeal of the GST demand succeed, given management expects no material impact? [S07]

## Sources

- [S01] businessdaily_2026-08-09.md | Business Daily Online (news website) | 2026-08-09 | https://businessdaily.example/markets/sarvottam-cables-q1-results
- [S02] ir_concall_2026-08-11.md | Q1 FY27 earnings call transcript (excerpt), hosted on company IR site | 2026-08-11 | https://ir.sarvottamcables.example/transcripts/q1fy27.pdf
- [S03] ir_press_release_2026-08-08.md | Sarvottam Cables Ltd, investor relations (company press release) | 2026-08-08 | https://ir.sarvottamcables.example/press/q1fy27
- [S07] nse_announcement_2026-09-02.md | NSE corporate announcement (company disclosure) | 2026-09-02 | https://nse.example/announcements/SRVCABLE/2026-09-02
