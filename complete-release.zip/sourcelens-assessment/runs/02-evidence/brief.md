## Snapshot

Sarvottam Cables Ltd (NSE: SRVCABLE) makes power cables, wires and conductors. Consolidated revenue for Q1 FY27, ended 30 June 2026, was ₹1,248 crore versus ₹1,058 crore in Q1 FY26, a reported 18.0% increase. [S03]

Q1 FY27 EBITDA was ₹140 crore versus ₹136 crore a year earlier; margin fell 170 basis points to 11.2% from 12.9%. Profit after tax was ₹82 crore versus ₹77 crore, with reported growth of 5.9%. [S03]

The primary release takes precedence over the later news article's ₹1,428 crore revenue and 35% growth for the same quarter. That discrepancy remains unexplained. [S01][S03]

## Bull case

- The order book reached ₹3,900 crore on 30 June 2026, versus ₹3,150 crore a year earlier. Exports contributed 21% of Q1 FY27 revenue versus 16% in Q1 FY26. [S03]
- Management guides FY27 revenue growth of 15–17% and expects Bharuch commercial production in Q3 FY27, adding about 30% to cable capacity. It thinks data-centre cables could double their roughly 9% share of domestic revenue within two years. [S02][S03]
- Pledging fell to 4.1% of promoter holdings on 30 June 2026, from 6.0% in March 2026 and 11.5% in June 2025. The reported 35% figure concerns March 2024 and is historical. [S04][S08]

## Bear case

- Management attributes margin pressure mainly to copper. About two-thirds of contracts have price-variation clauses with one-to-two-quarter reset lags; management's expected copper-cost recovery over the next two quarters remains unproven. [S02][S03]
- On 11 August 2026, the CFO said receivable days rose from 78 to 96 over the past year because two state utilities paid slowly; management reported no defaults. Bharuch capex totals ₹620 crore, about 70% spent. Reported net debt/equity was 0.35 times, with its measurement date unspecified. [S02]
- The ₹46.3 crore GST demand includes interest and penalty for FY2020-21 and FY2021-22 input-tax-credit claims. The company intended to appeal and expected no material impact; neither statement establishes the outcome. [S07]

## Open questions

- How much copper cost will be recovered? Will Bharuch start on time and within budget? When will utility customers pay, and what are receivable aging and operating cash-flow effects? [S02][S03]
- Has the GST appeal been filed, and what payment or provision is required? Have leverage or pledges changed since the supplied disclosures? [S02][S07][S08]
- Not supplied in the pack: share price, market capitalization, valuation multiples and suitable peer comparisons as of 23 September 2026.

## Sources

- [S01] `businessdaily_2026-08-09.md` — published 2026-08-09 — [Supplied URL (unverified)](https://businessdaily.example/markets/sarvottam-cables-q1-results)
- [S02] `ir_concall_2026-08-11.md` — published 2026-08-11 — [Supplied URL (unverified)](https://ir.sarvottamcables.example/transcripts/q1fy27.pdf)
- [S03] `ir_press_release_2026-08-08.md` — published 2026-08-08 — [Supplied URL (unverified)](https://ir.sarvottamcables.example/press/q1fy27)
- [S04] `marketwatchindia_2024-03-18.md` — published 2024-03-18 — [Supplied URL (unverified)](https://marketwatchindia.example/2024/03/sarvottam-promoter-pledge)
- [S07] `nse_announcement_2026-09-02.md` — published 2026-09-02 — [Supplied URL (unverified)](https://nse.example/announcements/SRVCABLE/2026-09-02)
- [S08] `nse_shareholding_2026-07-15.md` — published 2026-07-15 — [Supplied URL (unverified)](https://nse.example/shareholding/SRVCABLE/2026-06)
